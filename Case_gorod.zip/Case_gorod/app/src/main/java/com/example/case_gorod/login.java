package com.example.case_gorod;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
    }

    public void onClick(View V) {
        switch (V.getId()) {
            case R.id.sign_up_btn:
                Intent intentSignUp = new Intent(this, sign_up.class);
                startActivity(intentSignUp);
                break;
            case  R.id.log_in:
                Intent intentSigned = new Intent(this, MainActivity.class);
                startActivity(intentSigned);
                break;
        }
    }
}
